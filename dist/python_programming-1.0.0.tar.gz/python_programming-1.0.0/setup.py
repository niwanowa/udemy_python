from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk'],
    url='',
    license='',
    author='ky14311',
    author_email='',
    description=''
)
